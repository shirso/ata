<?php
/*
 * Template Name: Home Page
 */
?>
<?php get_header(); ?>


<?php the_post(); the_content(); ?>
<?php get_footer(); ?>