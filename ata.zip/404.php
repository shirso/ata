<?php get_header(); ?>
    <!---------- Body Two Part Open ---------->
        <section class="paddingtoplarger clearfix">
            <!------ Body Left Part Open ------>
            <div class="col-md-12 prd">
                <div class="why-us-body-content">
                    <div id="error404" class="clearfix">
                                      <div class="error404-num"></div>
                                    <div class="error404-mess">
                                    <img src="<?php echo get_bloginfo('template_url')?>/img/404.jpg" height="202" width="100%"  class="thumbnail img-responsive" alt=""> 
                                        <?php //get_search_form(); /* outputs the default Wordpress search form */ ?>
                                    </div>
                                    </div><!--#error404 .post-->
                    </div>
                <!-- It's Border and It's must-->
                <div class="side-border"></div>
                <!-- It's Border and It's must-->
            </div>
               
            <div class="clearfix"></div>
        </section>
        <!---------- Body Two Part Close ---------->
<?php get_footer(); ?>