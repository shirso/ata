 <!--------------- Sidebar Open -------------------->
        <div class="col-sm-3">
                <div class="sidebar-area">  
                    <?php if ( ! dynamic_sidebar( 'Default SideBar' )) :  
                     endif; ?>
                </div>
            </div>
 <!--------------- Sidebar Close -------------------->
        
       